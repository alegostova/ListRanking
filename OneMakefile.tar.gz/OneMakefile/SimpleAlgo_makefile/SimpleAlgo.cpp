#include <iostream>
#include <cstdlib>
#include <cmath>
#include <cassert>

#include <fcntl.h>
#include <sys/stat.h>


using namespace std;

static const char* helpText =
    "Usage: simpleAlgo inputFile outputFile\n"
    "  inputFile   - name of source file\n"
    "  outputFile  - name of result file. If file is alerady exists, than it will be rewritten.";

// типы off64_t и int64_t на моей системе - тоже самое что и long long int,
// поэтому пока что я не заморачиваюсь с ними
static const off64_t blockCountForIO = 262144; // 262144 : if FS block size = 4096B,
                                             //        than we will write data by packs of 1GB


int main(int argc, char** argv)
{
  if (argc != 3)
  {
    cout << "Wrong amount of arguments.\n" << helpText << endl;
    return 1;
  }

  int sourceFD = open64(argv[1], O_RDONLY, S_IRWXU | S_IRWXG);
  if (sourceFD == -1)
  {
    cout << "Fail to open source file: " << argv[2] << endl;
    return 2;
  }

  int resultFD = open64(argv[2], O_WRONLY | O_TRUNC | O_CREAT, S_IRWXU | S_IRWXG);
  if (resultFD == -1)
  {
    cout << "Fail to create result file." << endl;
    close(sourceFD);
    close(resultFD);
    return 3;
  }

  struct stat64 fileStats;
  if (fstat64(sourceFD, &fileStats) == -1)
  {
    cout << "Failed to get info about FS." << endl;
    close(sourceFD);
    close(resultFD);
    return 4;
  }
  if (fileStats.st_size % sizeof(int64_t))
  {
    cout << "Wrond size of source file." << endl;
    close(sourceFD);
    close(resultFD);
    return 5;
  }

  // Оптимальный размер блока для операций IO в ФС
  int64_t FSBlockSize = static_cast<int64_t>(fileStats.st_blksize);
  // Количество элементов в блоке для записи
  int64_t elementCountInBlock = FSBlockSize  * blockCountForIO / sizeof(int64_t);
  // Количество элементов в файле
  int64_t totalElemenCount = fileStats.st_size / sizeof(int64_t);
  // Количество блоков для чтения в исходном файле
  int64_t blockCount = fileStats.st_size / (elementCountInBlock * sizeof(int64_t)) + 1;

  // Установленых рангов
  int64_t readedElements = 0;
  // Текущая позиция
  int64_t currentPosition = 0;
  // Номер последнего прочтенного блока
  int64_t lastBlock = -1;

  int64_t* buf = 0;
  while (true)
  {
    int64_t currentBlock = currentPosition / elementCountInBlock;
    if (lastBlock != currentBlock)
    {
      lastBlock = currentBlock;
      int64_t bytesToRead = (currentBlock == (blockCount - 1))
                            ? fileStats.st_size
                              - (elementCountInBlock * (blockCount - 1) * sizeof(int64_t))
                            : elementCountInBlock * sizeof(int64_t);
      if (buf)
        delete[] buf;
      buf = new int64_t[bytesToRead / sizeof(int64_t)];
      pread(sourceFD, buf, bytesToRead,
            lseek64(sourceFD, currentBlock * elementCountInBlock * sizeof(int64_t), SEEK_SET));
    }

    pwrite64(resultFD, &readedElements, sizeof(int64_t), currentPosition * sizeof(int64_t));
    ++readedElements;

    int64_t positionInBlock = currentPosition % elementCountInBlock;

    currentPosition = buf[positionInBlock];
    if (currentPosition == -1)
      break;
  }

  close(sourceFD);
  close(resultFD);

  if (readedElements != totalElemenCount)
  {
    cout << "Ranks is setted, but may be there loop in source file. Data in result file with thrash."
         << endl;
    return 6;
  }

  cout << "Ranks setted successfully." << endl;

  return 0;
}
