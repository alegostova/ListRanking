// эта программа создает файлы для тестирования

#include <stxxl.h>
#include <cmath>

using namespace stxxl;


static const char* helpText =
    "Usage: createFile n nameOfOutPutFile\n"
    "  n                - natural number in range [1, 35]: 2^n = count of elements in result file;\n"
    "  nameOfOutPutFile - name of result file. If file is alerady exists, than it will be rewritten.";


static const int64 MB = 1024 * 1024; // bytes in MB =)
static const int64 internalMemoryForUse = 1024 * MB;

class VertexGenerator
{
  public:
    VertexGenerator()
      : m_counter(-1)
    {}

    int64 operator()()
    {
      return ++m_counter;
    }

  private:
    int64 m_counter;
};


struct Edge
{
    int64 node;
    int64 successor;

    Edge(int64 node_, int64 successor_)
      : node(node_),
        successor(successor_)
    {}

    Edge()
    {}
};


class EdgeGenerator
{
  public:
    EdgeGenerator(vector<int64>::const_iterator from, vector<int64>::const_iterator to)
      : m_current(from),
        m_last(to)
    {
//      assert((m_current - m_last) % 2);
    }

    Edge operator()()
    {
      Edge ret;
      if (m_current != (m_last - 1))
      {
        ret.node = *m_current;
        ret.successor = *(++m_current);
        if (ret.successor == 0)
          ret.successor = -1;
      }

      return ret;
    }

  private:
    vector<int64>::const_iterator m_current;
    vector<int64>::const_iterator m_last;
};


struct EdgeCompare
{
    Edge min_value() const
    {
      return Edge(std::numeric_limits<int>::min(), -1);
    }

    Edge max_value() const
    {
      return Edge(std::numeric_limits<int>::max(), -1);
    }

    bool operator() (const Edge& e1, const Edge& e2) const
    {
      return e1.node < e2.node || (e1.node == e2.node && e1.successor < e2.successor);
    }
};


class ResultSaver
{
  public:
    ResultSaver(vector<Edge>::const_iterator from, vector<Edge>::const_iterator to)
      : m_current(from),
        m_last(to)
    {}

    int64 operator()()
    {
      if (m_current != (m_last))
        return (m_current++)->successor;

      return -1;
    }

  private:
    vector<Edge>::const_iterator m_current;
    vector<Edge>::const_iterator m_last;
};


int main(int argc, char** argv)
{
  if (argc != 3)
  {
    std::cout << "Wrong amount of arguments.\n" << helpText << std::endl;
    return 1;
  }

  int n = atoi(argv[1]);
  if ((n < 1) || (n > 35))
  {
    std::cout << "Wrong first parameter.\n" << helpText << std::endl;
    return 2;
  }

  syscall_file outputFile(argv[2], file::CREAT | file::RDWR  | file::TRUNC);

  int64 totalElementCount = std::pow(2, n);

  std::cout << "Creating nodes... " << std::flush;
  vector<int64> nodes(totalElementCount);
  generate(nodes.begin(), nodes.end(), VertexGenerator(), 18);
  std::cout << "done" << std::endl;

  std::cout << "Random permutatition of nodes... " << std::flush;
  random_shuffle(nodes.begin(), nodes.end(), internalMemoryForUse);
  int64 lastElem = *nodes.begin();
  nodes.push_back(lastElem ? lastElem : -1);
  std::cout << "done" << std::endl;

//  for (int i = 0; i != nodes.size(); ++i)
//    std::cout << i << "\t";
//  std::cout << std::endl;

//  for (int i = 0; i != nodes.size(); ++i)
//    std::cout << nodes[i] << "\t";
//  std::cout << std::endl;

  std::cout << "Creating edges... " << std::flush;

  vector<Edge> edges(totalElementCount);
  generate(edges.begin(), edges.end(), EdgeGenerator(nodes.begin(), nodes.end()), 18);
  std::cout << "done" << std::endl;

  nodes.clear(); // dont need more

//  for (int i = 0; i != edges.size(); ++i)
//    std::cout << "(" << edges[i].node << "," << edges[i].successor << ")\t";
//  std::cout << std::endl;

  std::cout << "Sorting edges... " << std::flush;
  sort(edges.begin(), edges.end(), EdgeCompare(), internalMemoryForUse);
  std::cout << "done" << std::endl;

//  for (int i = 0; i != edges.size(); ++i)
//    std::cout << "(" << edges[i].node << "," << edges[i].successor << ")\t";
//  std::cout << std::endl;


  std::cout << "Saving result into \"" << argv[2] << "\"... " << std::flush;
  vector<int64> result(&outputFile, totalElementCount);
  generate(result.begin(), result.end(), ResultSaver(edges.begin(), edges.end()), 18);
  std::cout << "done" << std::endl;

//  for (int i = 0; i != result.size(); ++i)
//    std::cout << result[i] << "\t";
//  std::cout << std::endl;

  return 0;
}
