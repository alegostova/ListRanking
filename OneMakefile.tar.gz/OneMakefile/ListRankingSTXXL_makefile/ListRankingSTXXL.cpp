#include <stxxl.h>
#include <stxxl/stack>
#include <iostream>

using namespace stxxl;


static const char* helpText =
    "Usage: listRanking inputFile outputFile\n"
    "  inputFile   - name of source file\n"
    "  outputFile  - name of result file. If file is alerady exists, than it will be rewritten.";


static const int64 internalMemotyForUse = 1024 * 1024 * 1024; // = 1024 MB
static const unsigned memoryForQueue = 33554432; // = 2^35 / 1024
static const int64 minInt64 = std::numeric_limits<int64>::min();


struct ElementOfNodeList
{
    int64 u;
    int64 v;
    int64 lv;

    ElementOfNodeList(int64 u_ = minInt64, int64 v_ = minInt64, int64 lv_ = minInt64)
      : u(u_),
        v(v_),
        lv(lv_)
    {}
};

struct ElementOfNodeListComparator
{
    bool operator()(const ElementOfNodeList& a, const ElementOfNodeList& b) const
    {
      return (a.u < b.u) || ((a.u == b.u) && (a.v < b.v));
    }

    static ElementOfNodeList min_value()
    {
      return ElementOfNodeList();
    }
};


struct ElementOfNodeListComparator1
{
    bool operator()(const ElementOfNodeList& a, const ElementOfNodeList& b) const
    {
      return (a.u > b.u) || ((a.u == b.u) && (a.v > b.v));
    }

    static ElementOfNodeList min_value()
    {
      return ElementOfNodeList(std::numeric_limits<int64>::max(), std::numeric_limits<int64>::max(), std::numeric_limits<int64>::max());
    }
};


struct ElementOfSendList
{
  int64 w;
  int64 u;

  ElementOfSendList(int64 w_ = minInt64, int64 u_ = minInt64)
    : w(w_),
      u(u_)
  {}
};


struct ElementOfSendListComparator
{
    bool operator()(const ElementOfSendList& a, const ElementOfSendList& b) const
    {
      if (a.w == -1)
        return true;
      if (b.w == -1)
        return false;
      return a.w > b.w || (a.w == b.w && a.u > b.u);
    }

    static ElementOfSendList min_value()
    {
      return std::numeric_limits<int64>::max();
    }

};


int main(int argc, char** argv)
{
  if (argc != 3)
  {
    std::cout << "Wrong amount of arguments.\n" << helpText << std::endl;
    return 1;
  }

  syscall_file sourceFile(argv[1], file::RDWR);
  if (sourceFile.size() % sizeof(int64))
  {
    std::cout << "Source file damaged or truncated." << std::endl;
    return 2;
  }

  vector<int64> source(&sourceFile);

  // Step 1
  PRIORITY_QUEUE_GENERATOR<ElementOfNodeList, ElementOfNodeListComparator,
                           internalMemotyForUse, memoryForQueue>::result
      processingData(internalMemotyForUse / 2, internalMemotyForUse / 2);

  for (vector<int64>::const_iterator it = source.begin(); it != source.end(); ++it)
  {
    int64 v = *it;
    if (v == -1)
      continue;

    int64 u = it - source.begin();

    if (u < v)
      processingData.push(ElementOfNodeList(v, u, -1));
    else
      processingData.push(ElementOfNodeList(u, v, 1));
  }

  // Step 2
  PRIORITY_QUEUE_GENERATOR<ElementOfNodeList, ElementOfNodeListComparator1,
                           internalMemotyForUse, memoryForQueue>::result
      sendList1(internalMemotyForUse / 2, internalMemotyForUse / 2);

  while (processingData.top().u >= 0 && processingData.top().v >= -1)
  {
    ElementOfNodeList w = processingData.top();
    processingData.pop();

    if (processingData.top().u == w.u)
    {
      ElementOfNodeList v = processingData.top();
      processingData.pop();
      processingData.push(ElementOfNodeList(w.v, v.v, v.lv - w.lv));
    }
    else
    {
      processingData.push(ElementOfNodeList(w.v, minInt64 / 2/*-2*/, -w.lv));
    }

    sendList1.push(ElementOfNodeList(w.v, w.u, w.lv));
  }

  // Step 3
  PRIORITY_QUEUE_GENERATOR<ElementOfSendList, ElementOfSendListComparator,
                           internalMemotyForUse, memoryForQueue>::result
      resultPQ(internalMemotyForUse / 2, internalMemotyForUse / 2);

  PRIORITY_QUEUE_GENERATOR<ElementOfSendList, ElementOfSendListComparator,
                           internalMemotyForUse, memoryForQueue>::result
      tmp(internalMemotyForUse / 2, internalMemotyForUse / 2);

  tmp.push(ElementOfSendList(0, 0));
  resultPQ.push(ElementOfSendList(0, 0));

  while (!sendList1.empty())
  {
    while (sendList1.top().u != tmp.top().w)
    {
      tmp.pop();
      assert(!tmp.empty());
    }
    int64 lastDist = tmp.top().u - sendList1.top().lv;
    resultPQ.push(ElementOfSendList(sendList1.top().v, lastDist));
    tmp.push(ElementOfSendList(sendList1.top().v, lastDist));
    sendList1.pop();
    if (sendList1.top().u != tmp.top().w)
      tmp.pop();
  }


  syscall_file outFile(argv[2], file::WRONLY | file::CREAT | file::TRUNC);
  vector<int64> result(&outFile);
  result.reserve(source.size());
  while (!resultPQ.empty())
  {
    result.push_back(resultPQ.top().u);
    resultPQ.pop();
  }

  return 0;
}

